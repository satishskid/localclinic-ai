PNG icons created - use SVG or convert manually
